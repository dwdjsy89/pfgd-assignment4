~~~NOTICE~~~

These objects were created using the ProBuilder tool. They aren't used throughout the scene since they slowdown the process of editing your Level. 

If any adjustments are made to these objects, they won't affect the rest of the level.